function notAvailableAlert()
{
    alert("This function is not available right now");
}