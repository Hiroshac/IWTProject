//This sets a dynamic user name
document.getElementById("username").innerHTML="Hirosha";